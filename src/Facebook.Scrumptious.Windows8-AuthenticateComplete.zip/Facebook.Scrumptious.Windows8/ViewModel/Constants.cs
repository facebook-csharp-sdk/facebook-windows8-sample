﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Facebook.Scrumptious.Windows8.ViewModel
{
    class Constants
    {
        public static readonly string FBActionBaseUri = "http://pratapgarh.com/fbtest/";
        public static readonly string FacebookAppId = "540541885996234";
        public static readonly string FacebookAppGraphAction = "scrumptiousmsft";
    }
}
